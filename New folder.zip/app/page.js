 import { Typography } from "@mui/material";
import Home from "./home/page";
import Register from "./register/page";
export default function Page() {
  return (
    <>
   
      <Register />
    </>
  ); 
}
